package com.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
@Table(name="emptab06")
public class Employee {

	@Id
	@Column(name="ID")
	private int id;
	@NotNull(message="Please Entr Name")
	@Size(min=2,max=5,message="Enter 2-5 chars only")
	@Pattern(regexp="[A-Za-z]{2,5}",message="please enter Uppdercase 2-5 char only")
	@Column(name="ename")

	private String name;
	@Column(name="esal")

	private double sal;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int id, String name, double sal) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", sal=" + sal + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
    
}
