package com.app.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.app.entity.Employee;
import com.app.util.HibernateUtil;

public class Test {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.buildSessionFactory();
		Session ses=sf.openSession();
		Transaction tx=ses.beginTransaction();
		Employee e1=new Employee();
		e1.setId(55);
		e1.setName("Ram");
		e1.setSal(33.3);
		ses.save(e1);
		tx.commit();
		ses.close();
		/*}catch(Exception ex)
		{
		ex.printStackTrace();
		}*/
	}
}
