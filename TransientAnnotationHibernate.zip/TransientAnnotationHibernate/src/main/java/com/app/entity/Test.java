package com.app.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {
	
	public static void main(String[] args) {
		
		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Employee e=new Employee();
		e.setEid(1);
		e.setEname("Pratibha");
		e.setEsal(1000000);
		
		Transaction tx=s.beginTransaction();
		s.save(e);
	    //s.update(e);

		tx.commit();
	}

}
