package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.dao.IEmployeeDAO;
import com.nt.model.Employee;

@Service("empservice")
public class EmployeeMgmtService implements IemployeeMgmtservice{
	
	@Autowired
	private IEmployeeDAO empdao;

	@Override
	public List<Employee> fetchAllEmployeeByDesg(String desg1, String desg2, String desg3) throws Exception {
		// TODO Auto-generated method stub
		
		List<Employee> list=empdao.getEmployeeByDesigs(desg1,desg2,desg3);
		
		return list;
	}
	
	
	
	

}
