package com.nt;


import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.nt.controller.PayrollOperationController;
import com.nt.model.Employee;

@SpringBootApplication
public class SbMprojectM3LayeredApplication {

	public static void main(String[] args) {
		ApplicationContext ctx=SpringApplication.run(SbMprojectM3LayeredApplication.class, args);
		PayrollOperationController controller=ctx.getBean("payroll",PayrollOperationController.class);
		
		try {
			List<Employee> list=controller.showEmployeeByDesg("Clerk","Manager","Salesman");
			list.forEach(emp->{
				System.out.println(emp);
			});
		}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				System.out.println("Internal problem:try again::"+e.getMessage());
			}
			((ConfigurableApplicationContext) ctx).close();
		
	}

}
