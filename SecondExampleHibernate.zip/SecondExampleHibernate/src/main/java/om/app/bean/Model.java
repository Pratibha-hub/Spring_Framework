package om.app.bean;

import javax.persistence.Column;
import javax.persistence.Id;

import org.hibernate.annotations.Entity;
import org.hibernate.annotations.Table;

@Entity
@Table(name="cus")
public class Model {
	@Id
	@Column(name="cid")
	private int custid;
	public Model() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Model(int custid, String cusname, String cusadd) {
		super();
		this.custid = custid;
		this.cusname = cusname;
		this.cusadd = cusadd;
	}
	@Override
	public String toString() {
		return "Model [custid=" + custid + ", cusname=" + cusname + ", cusadd=" + cusadd + "]";
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getCusname() {
		return cusname;
	}
	public void setCusname(String cusname) {
		this.cusname = cusname;
	}
	public String getCusadd() {
		return cusadd;
	}
	public void setCusadd(String cusadd) {
		this.cusadd = cusadd;
	}
	@Column(name="Cname")
	private String cusname;
	@Column(name="Cadd")
	private String cusadd;
	

}
