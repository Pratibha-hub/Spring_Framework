package com.app.test;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

import com.app.util.HibernateUtil;

public class Test {

	public static void main(String[] args) {
		Transaction tx=null;
		try(Session ses=HibernateUtil.getSf().openSession()) {
			
			tx=ses.beginTransaction();
			
			//case 2: non �select operation--
			
			String sql="update Emptab05 set Name=:a, salary=:b where ID=:c";
			NativeQuery q=ses.createNativeQuery(sql);
			q.setParameter("a","Ramesh kumar");
			q.setParameter("b",5000);
			q.setParameter("c",10);
			int count =q.executeUpdate();
			tx.commit();
			ses.close();
			System.out.println(count);
			
			/*Case 1: using non - addEntity �full loading particular row/full row data fetch
			 * 
			 * String sql="select * from Emptab04"; NativeQuery
			 * q=ses.createNativeQuery(sql); //using addEntity �full loading: for full loading of table use below query
			 * //q.addEntity(Employee.class); List<Object[]>obs=q.list();
			 * for(Object[]ob:obs) { System.out.println(ob[0]+","+ob[1]+","+ob[2]); }
			 */
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
