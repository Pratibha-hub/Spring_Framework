package com.example.boot.runner;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

@Component
public class SpringbootApplicationRunner implements ApplicationRunner {

	@Override
	public void run(ApplicationArguments args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Hii Application Runner");
	}

	/*
	 * @Override public void run(String... args) throws Exception { // TODO
	 * Auto-generated method stub System.out.println("Hii CommandLine Runner");
	 * 
	 * }
	 * 
	 * @Override public int getOrder() { // TODO Auto-generated method stub return
	 * 50; }
	 */
	
	
}

