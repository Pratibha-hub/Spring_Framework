package com.example.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToRunnerusingCommandLineArgumentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToRunnerusingCommandLineArgumentApplication.class, args);
		System.out.println("Starter class Called");
	}

}
