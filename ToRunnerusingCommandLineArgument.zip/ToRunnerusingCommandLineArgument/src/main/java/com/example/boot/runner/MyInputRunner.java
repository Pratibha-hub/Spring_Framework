package com.example.boot.runner;

import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class MyInputRunner implements CommandLineRunner{

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Hello CommandLineRunner");
		 System.out.println(args[1]);
		 System.out.println(Arrays.asList(args));
		 System.out.println("End of CommandLineRunner");
		
	}

}
