package com.app.entity;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;

@Entity
@Table(name="SETMAP")
public class Customer {
	
	@Id
	@Column(name="ID")
	private int cusid;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int cusid, String cusname, Set<String> setdata, Map<Integer, String> mapdata) {
		super();
		this.cusid = cusid;
		this.cusname = cusname;
		this.setdata = setdata;
		this.mapdata = mapdata;
	}
	@Override
	public String toString() {
		return "Customer [cusid=" + cusid + ", cusname=" + cusname + ", setdata=" + setdata + ", mapdata=" + mapdata
				+ "]";
	}
	public int getCusid() {
		return cusid;
	}
	public void setCusid(int cusid) {
		this.cusid = cusid;
	}
	public String getCusname() {
		return cusname;
	}
	public void setCusname(String cusname) {
		this.cusname = cusname;
	}
	public Set<String> getSetdata() {
		return setdata;
	}
	public void setSetdata(Set<String> setdata) {
		this.setdata = setdata;
	}
	public Map<Integer, String> getMapdata() {
		return mapdata;
	}
	public void setMapdata(Map<Integer, String> mapdata) {
		this.mapdata = mapdata;
	}
	@Column(name="Name")
	private String cusname;
	@Column(name="data")
	@ElementCollection
	@CollectionTable(name="custdata",joinColumns=@JoinColumn(name="cusid"))
	private Set<String> setdata=new HashSet<String>();
	@Column(name="data")
	@ElementCollection
	@CollectionTable(name="maptab",joinColumns=@JoinColumn(name="cusid"))
	@MapKeyColumn(name="pos")
	private Map<Integer, String> mapdata=new TreeMap<Integer, String>();

}
