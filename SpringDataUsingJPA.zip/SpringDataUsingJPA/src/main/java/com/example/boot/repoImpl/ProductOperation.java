package com.example.boot.repoImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.boot.model.Product;
import com.example.boot.repo.ProductRepository;

@Service
public class ProductOperation implements CommandLineRunner {

	@Autowired
	private ProductRepository repo;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
	//	case1: success
		//Product p = repo.findByProdName("LAPTOP");
		
	//  case 2:	success
		/*
		 * List<Product> p = repo.findByProdNameLike("P%"); System.out.println(p);
		 */
		
	//  case 3:	fail
	
	 // Product p = repo.findByProdName("Null");
	//  System.out.println(p);

	 // List<Product> p1 =repo.findByProdNameIsNull();
	  
	 // repo.findByProdNameIsNull().forEach((System.out::println));
	 

  //case 4:success
	//List<Product> p=repo.findByProdCostGreaterThan(5.8);
	//System.out.println(p);
		 
	//case 5:fail
		//List<Product> p= repo.findByProdCostIn(null);
		//System.out.println(p);
		 
	//case 6:success
		 
		// List<Product> p= repo.findByProdIdOrProdCost(5, 6.8);
		//System.out.println(p);
		
  //case 7 : success
		
		//List<Product> p=repo.findByProdIdBetween(6,8);
		//System.out.println(p);
		
 //case 7 : success
		//List<Product> p=repo.findByProdCostLessThanOrderByProdName(5000.8);
		//System.out.println(p);
		
		
		
		
	/*
	 * repo.save(new Product("PEN", 6.8, "BLUE")); repo.save(new Product("PENCIAL",
	 * 5.8, "RED")); repo.save(new Product("MOBILE", 5000.8, "BLACK"));
	 * repo.save(new Product("LAPTOP", 2000.8, "GRAY")); repo.save(new Product("TV",
	 * 5000.8, "yellow")); repo.save(new Product("LHONE", 2000.8, "pink"));
	 * repo.save(new Product("Null", 5000.8, "green")); repo.save(new
	 * Product("Null", 2000.8, "orange"));
	 */
		 
		/* 2.*****************Find *******************/
		// 2.1 method.
		/*
		 * Optional<Product> p = repo.findById(3); if(p.isPresent()) {
		 * System.out.println(p.get()); } else { System.out.println("No Data found"); }
		 * //2.2 Method. repo.findAll().forEach((System.out::println)); 3.
		 * *****************Delete*************** //3.1 Delete by specific Id
		 * repo.deleteById(3); //3.2 Delete all Rows one by one in (Sequence order)
		 * repo.deleteAll(); //Multiple Query fired No of record = no of Query //3.3
		 * Delete all rows in Batch (Single Query fired) repo.deleteAllInBatch();
		 */
	repo.deleteById(15);
	}

}
