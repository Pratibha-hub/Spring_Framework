package com.example.boot.repo;

import org.springframework.stereotype.Repository;

import com.example.boot.model.Product;

import java.util.Collection;
import java.util.List;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

	Product findByProdName(String prodName);
	List<Product> findByProdNameLike (String prodName);

	List<Product> findByProdNameIsNull();
	List<Product> findByProdCostGreaterThan(Double cost);
	List<Product> findByProdCostIn(Collection<Double> costs);
	List<Product> findByProdIdOrProdCost(Integer pid, Double cost);
	List<Product> findByProdIdBetween (Integer pid1, Integer pid2);
	List<Product> findByProdCostLessThanOrderByProdName(Double cost);






	
}
