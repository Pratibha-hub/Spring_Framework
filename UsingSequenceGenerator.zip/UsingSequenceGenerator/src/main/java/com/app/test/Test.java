package com.app.test;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.entity.Employee;
import com.app.util.HibernateUtil;

public class Test {
	
	public static void main(String[] args) {
		Transaction tx=null;
		try(Session ses=HibernateUtil.getSf().openSession()){
		tx=ses.beginTransaction();
		Employee e=new Employee();
		e.setEname("A");
		e.setEsal(2.6);
		Serializable s=ses.save(e);
		//downcat and autounbox 
		Integer eid=(Integer)s;
		int empId=eid;
		System.out.println("employee created with id:"+empId);
		tx.commit();
		//ses.close();
		}catch(Exception ex)
		{
		ex.printStackTrace();
		}

	}

}
