package com.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.Table;

@Entity
@Table(name="employtab")
@SecondaryTables({
		@SecondaryTable(name="emptwo"),
		@SecondaryTable(name="empextatab",pkJoinColumns = @PrimaryKeyJoinColumn(name="eidfk"))
})
public class Employee {
	
	@Id
	@Column(name="ID")
	private int eid;
	@Column(name="Name")
	private String ename;
	@Column(name="Salary",table="emptwo")
	private double esal;
	@Column(name="Project",table="empextatab")
	private String prjt;
	@Column(name="Depart", table="empextatab")
	private String dept;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int eid, String ename, double esal, String prjt, String dept) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esal = esal;
		this.prjt = prjt;
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esal=" + esal + ", prjt=" + prjt + ", dept=" + dept
				+ "]";
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getEsal() {
		return esal;
	}
	public void setEsal(double esal) {
		this.esal = esal;
	}
	public String getPrjt() {
		return prjt;
	}
	public void setPrjt(String prjt) {
		this.prjt = prjt;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	
	

}
