package com.app.test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.entity.Employee;
import com.app.util.HibernateUtil;

public class Test {
	public static void main(String[] args) {
		Transaction tx = null;
		try (Session ses = HibernateUtil.getSf().openSession()) {
		tx=ses.beginTransaction(); 
		
		//case 2: setFirstResult(int index) -------setMaxResults(int size)

		
		String hql = "from Employee";
		Query q = ses.createQuery(hql);
		q.setFirstResult(4);
		q.setMaxResults(6);
		List<Employee> empob = q.list();
		empob.forEach(System.out::println);
		 
		//case 1: data store
		
		/*
		 * Employee emp = new Employee(); emp.setEid(1001); emp.setEname("Sumit");
		 * emp.setEsal(33.3); Employee emp1 = new Employee(); emp1.setEid(1002);
		 * emp1.setEname("Sujeeta"); emp1.setEsal(31.4); Employee emp2 = new Employee();
		 * emp2.setEid(1003); emp2.setEname("anil"); emp2.setEsal(44.4); Employee emp3 =
		 * new Employee(); emp3.setEid(1004); emp3.setEname("amit"); emp3.setEsal(34.3);
		 * Employee emp4 = new Employee(); emp4.setEid(1005); emp4.setEname("raja");
		 * emp4.setEsal(312.3); ses.save(emp); ses.save(emp1); ses.save(emp2);
		 * ses.save(emp3); ses.save(emp4); ses.save(emp4); tx.commit();
		 */
		  
		 
		} catch (Exception ex) {
		ex.printStackTrace();
		}
	}

}
