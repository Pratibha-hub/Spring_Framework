package com.example.boot.runner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.boot.repo.ProductRepository;

@Component
public class SelectOperationUsingQueryParam implements CommandLineRunner{

	@Autowired
	private ProductRepository rep;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		//rep.getAllProductData().stream().map((ob)->ob[0]+","+ob[1]).forEach(System.out::println);

		
	}

}
