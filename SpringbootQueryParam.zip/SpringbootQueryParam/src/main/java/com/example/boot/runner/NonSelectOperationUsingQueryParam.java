package com.example.boot.runner;

public class NonSelectOperationUsingQueryParam {

}
