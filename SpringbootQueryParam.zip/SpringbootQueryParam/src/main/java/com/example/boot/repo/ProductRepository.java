package com.example.boot.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.boot.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

	
	//@Query("select p.vendorCode, p.prodCost from com.app.model.Product p")
	//List<Object[]> getAllProductData();
	/*
	 * @Query("select p from Product p where p.vendorCode=:a or p.prodCost>:b")
	 * List<Product> getAllProducts(String a, Double b);
	 */
	
   // @Query("select p.vendorCode, p.prodCost from com.app.model.Product p")
	//List<Object[]> getAllProductData();

	/*
	 * @Query("select p.vendorCode from Product p where p.vendorCode=?1 or p.prodCost=?2"
	 * ) List<String> getAllProductsCodes(String a, Double b);
	 */
	
}
