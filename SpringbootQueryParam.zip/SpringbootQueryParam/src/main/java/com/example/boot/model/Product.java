package com.example.boot.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
	@Id
	private int pid;
	private String vendercode;
	private String prodName;
	private Double prodcost;
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", vendercode=" + vendercode + ", prodName=" + prodName + ", prodcost="
				+ prodcost + "]";
	}
	public String getVendercode() {
		return vendercode;
	}
	public void setVendercode(String vendercode) {
		this.vendercode = vendercode;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public Double getProdcost() {
		return prodcost;
	}
	public void setProdcost(Double prodcost) {
		this.prodcost = prodcost;
	}
	public Product(int pid, String vendercode, String prodName, Double prodcost) {
		super();
		this.pid = pid;
		this.vendercode = vendercode;
		this.prodName = prodName;
		this.prodcost = prodcost;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
