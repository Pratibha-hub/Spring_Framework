package com.app.test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.entity.HibernateUtil;
import com.app.entity.Module;
import com.app.entity.Product;

public class Test {

	public static void main(String[] args) {
		
		Transaction tx=null;
		try(Session s=HibernateUtil.getSf().openSession()){
			
			tx=s.beginTransaction();
			Module m1=new Module();
			m1.setMid(101);
			m1.setMname("A");
			Module m2=new Module();
			m2.setMid(102);
			m2.setMname("B");
			Product p1=new Product();
			p1.setPid(201);
			p1.setPname("A");
			p1.getMob().add(m1);
			p1.getMob().add(m2);
			s.save(p1);
			s.save(m2);
			s.save(m1);
			tx.commit();
			
			
		}
	
}
}