package com.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Module_tab")
public class Module {
	
	@Id
	@Column(name="ID")
	private int mid;
	public Module() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Module(int mid, String mname, String modtype) {
		super();
		this.mid = mid;
		this.mname = mname;
		this.modtype = modtype;
	}
	@Override
	public String toString() {
		return "Module [mid=" + mid + ", mname=" + mname + ", modtype=" + modtype + "]";
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getModtype() {
		return modtype;
	}
	public void setModtype(String modtype) {
		this.modtype = modtype;
	}
	@Column(name="Name")
	private String mname;
	@Column(name="Type")
	private String modtype;

}
