package com.app.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="product_tab")
public class Product {
	@Id
	@Column(name="ID")
	private int pid;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(int pid, Set<Module> mob, String pname, double pcost) {
		super();
		this.pid = pid;
		this.mob = mob;
		this.pname = pname;
		this.pcost = pcost;
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", mob=" + mob + ", pname=" + pname + ", pcost=" + pcost + "]";
	}
	
	@OneToMany
	@JoinColumn(name="midfk")
	private Set<Module>mob=new HashSet<Module>();

	public Set<Module> getMob() {
		return mob;
	}
	public void setMob(Set<Module> mob) {
		this.mob = mob;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPcost() {
		return pcost;
	}
	public void setPcost(double pcost) {
		this.pcost = pcost;
	}
	@Column(name="Product")
	private String pname;
	@Column(name="Cost")
	private double pcost;

}
