package com.app.test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.entity.Address;
import com.app.entity.Employee;
import com.app.entity.HibernateUtil;

public class Test {

	public static void main(String[] args) {
		
		Transaction tx=null;
		
		try(Session s= HibernateUtil.getSf().openSession()){
			
			tx=s.beginTransaction();
			Address a1=new Address();
			a1.setAddrid(101);
			a1.setLoc("Patna");
			a1.setPin(202011);
			
			Address a2=new Address();
			a2.setAddrid(102);
			a2.setLoc("Jharkhand");
			a2.setPin(202341);
			
			Address a3=new Address();
			a3.setAddrid(103);
			a3.setLoc("Noida");
			a3.setPin(212341);
			
			Employee e1=new Employee();
			e1.setId(201);
			e1.setEname("Pratibha");
			e1.setSal(1000000);
			e1.setAddr(a1);
			
			Employee e2=new Employee();
			e2.setId(202);
			e2.setEname("Shivam");
			e2.setSal(1000200);
			e2.setAddr(a3);
			
			Employee e3=new Employee();
			e3.setId(203);
			e3.setEname("Ravi");
			e3.setSal(1000001);
			e3.setAddr(a2);
			
			Employee e4=new Employee();
			e4.setId(206);
			e4.setEname(null);
			e4.setSal(1000000);
			e4.setAddr(null);
			
			s.save(e1);
			s.save(e2);
			s.save(e3);
			s.save(a1);
			s.save(a2);
			s.save(a3);
			s.save(e4);
			tx.commit();
			
			
		}
	}
}
