package com.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Address_tab2")
public class Address {
	
	@Id
	@Column(name="ID")
	private int addrid;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(int addrid, String loc, int pin) {
		super();
		this.addrid = addrid;
		this.loc = loc;
		this.pin = pin;
	}
	@Override
	public String toString() {
		return "Address [addrid=" + addrid + ", loc=" + loc + ", pin=" + pin + "]";
	}
	public int getAddrid() {
		return addrid;
	}
	public void setAddrid(int addrid) {
		this.addrid = addrid;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	@Column(name="Location")
	private String loc;
	@Column(name="Pincode")
	private int pin;

}
