package com.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Employee_Tabale2")
public class Employee {
	@Id
	@Column(name="ID")
	private int id;
	@Column(name="Name")
	private String ename;
	@Column(name="Salary")
	private double sal;
	@OneToOne
	@JoinColumn(name="aidFK",unique = true)
	private Address addr;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int id, String ename, double sal) {
		super();
		this.id = id;
		this.ename = ename;
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", ename=" + ename + ", sal=" + sal + ", addr=" + addr+ "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	
	public Employee(int id, String ename, double sal, Address addr) {
		super();
		this.id = id;
		this.ename = ename;
		this.sal = sal;
		this.addr = addr;
	}
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	
	

}
