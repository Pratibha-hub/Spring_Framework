package com.example.boot.repoIml;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.boot.model.Product;
import com.example.boot.repo.ProductRepository;

@Component
public class ProductRepoImplement implements CommandLineRunner {
	
	@Autowired
	private ProductRepository repo;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		/*1.*****************Save*******************/

		
		repo.save(new Product("PEN", 6.8, "BLUE"));
		repo.save(new Product("Pencil",5.9,"Green"));
		repo.save(new Product("PENCIAL", 5.8, "RED"));
		repo.save(new Product("MOBILE", 5000.8, "BLACK"));
		repo.save(new Product("LAPTOP", 2000.8, "GRAY"));


		
	}

}
