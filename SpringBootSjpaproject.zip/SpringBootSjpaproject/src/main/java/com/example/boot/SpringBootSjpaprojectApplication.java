package com.example.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSjpaprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSjpaprojectApplication.class, args);
	}

}
