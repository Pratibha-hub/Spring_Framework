package com.example.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootWithInputDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootWithInputDataApplication.class, args);
		System.out.println("Hello");
	}

}
