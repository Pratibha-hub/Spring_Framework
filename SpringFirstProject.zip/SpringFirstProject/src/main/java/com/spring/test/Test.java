package com.spring.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.bean.Product;
import com.spring.config.AppConfig;

public class Test {
 public static void main(String[] args) {
	ApplicationContext ac=new AnnotationConfigApplicationContext(AppConfig.class);
	Product p=(Product) ac.getBean("prodObj");
	System.out.println(p);
}
}
