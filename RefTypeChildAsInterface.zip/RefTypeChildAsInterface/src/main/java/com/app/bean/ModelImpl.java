package com.app.bean;

public class ModelImpl implements IModel {

}
