package com.app.bean;

public class Product {

	private IModel mod;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(IModel mod) {
		super();
		this.mod = mod;
	}

	@Override
	public String toString() {
		return "Product [mod=" + mod + "]";
	}

	public IModel getMod() {
		return mod;
	}

	public void setMod(IModel mod) {
		this.mod = mod;
	}
}
