package com.app.bean;

public interface IModel {
                                                          
}
