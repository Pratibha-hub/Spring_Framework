package com.app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.app.bean.IModel;
import com.app.bean.ModelImpl;
import com.app.bean.Product;

@Configuration
public class AppConfig {

	@Bean
	public IModel modObj() {
		ModelImpl m=new ModelImpl();
		return m;
	}
	@Bean
	public Product prodObj() {
		Product p=new Product();
		p.setMod(modObj());
		return p;
		
	}
	
	
}
