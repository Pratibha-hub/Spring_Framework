package com.xml.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.xml.bean.Employee;

public class Test {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("classpath:config.xml");
		Employee  e= (Employee) ac.getBean("empObj", Employee.class);
		e.setEmpId(10);
		e.setEmpname("Pratibha");
		System.out.println(e);
	}
}
