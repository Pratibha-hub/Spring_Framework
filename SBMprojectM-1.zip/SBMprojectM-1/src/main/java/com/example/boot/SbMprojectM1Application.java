package com.example.boot;

import java.io.PrintStream;
import java.time.LocalDateTime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import com.example.boot.bean.WishMessageGenerator;

@SpringBootApplication
public class SbMprojectM1Application {

	@Bean("ldt")
	public LocalDateTime createLDT() {
		System.out.println("SbMprojectM1Application.createLDT()");
		return LocalDateTime.now();
	}
	
	public static void main(String[] args) {
		//SpringApplication.run(SbMprojectM1Application.class, args);
		
		ApplicationContext ctx = SpringApplication.run(SbMprojectM1Application.class, args);
		WishMessageGenerator generator = ctx.getBean("wmg", WishMessageGenerator.class);
		String result = generator.showWishMessage("raja");
		System.out.println("result::" + result);
		((ConfigurableApplicationContext) ctx).close();
		
		
		
	}

}
