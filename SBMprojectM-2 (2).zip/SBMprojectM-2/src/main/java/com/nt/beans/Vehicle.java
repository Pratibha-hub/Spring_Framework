package com.nt.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component("vehicle")
public class Vehicle {
	
	@Autowired
	@Qualifier("engg")
	private IEngine engine;
	
	public Vehicle() {
		System.out.println("Vehicle::0-param constructor");
	}
	
	public void journey(String startplace, String stopplace) {
		engine.start();
		System.out.println("journey started::"+startplace);
		System.out.println("journey is progress");
		engine.stop();
		System.out.println("journey stoped::"+stopplace);
	}

}
