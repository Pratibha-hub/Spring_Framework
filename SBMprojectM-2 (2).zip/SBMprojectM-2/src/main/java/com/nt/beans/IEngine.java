package com.nt.beans;

public interface IEngine {

	public void start();
	public void stop();
}
