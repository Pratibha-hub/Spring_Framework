package com.app.bean;

public class A {
    private B ob1;

	public A() {
		super();
		// TODO Auto-generated constructor stub
	}

	public A(B ob1) {
		super();
		this.ob1 = ob1;
	}

	@Override
	public String toString() {
		return "A [ob1=" + ob1 + "]";
	}

	public B getOb1() {
		return ob1;
	}

	public void setOb1(B ob1) {
		this.ob1 = ob1;
	}
    
}
