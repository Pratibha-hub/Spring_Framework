package com.app.bean;

public class B {
   private C ob2;

public B() {
	super();
	// TODO Auto-generated constructor stub
}

public B(C ob2) {
	super();
	this.ob2 = ob2;
}

@Override
public String toString() {
	return "B [ob2=" + ob2 + "]";
}

public C getOb2() {
	return ob2;
}

public void setOb2(C ob2) {
	this.ob2 = ob2;
}
}
