package com.app.bean;

public class C {
  private int id;

public C() {
	super();
	// TODO Auto-generated constructor stub
}

public C(int id) {
	super();
	this.id = id;
}

@Override
public String toString() {
	return "C [id=" + id + "]";
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}
  
}
