package com.example.boot.model;

import org.springframework.boot.convert.DataSizeUnit;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.Data;
public class Company {

	@Data
	private String name;
	private String location;
	private Integer size;
	private double turnover;
	private String catogery;
	
	@RestController
	@RequestMapping("/company/api")
	@GetMapping("/show")
	public ResponseEntity<Company> showcompanyDetail(){
		Company com=new Company("HCL","hyd",100,50000000.0,"IT");
		return new ResponseEntity<Company>(company,HttpStatus.OK);
	}
	
}

