package com.app.test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.Util.HibernateUtil;
import com.app.entity.Address;
import com.app.entity.Classes;
import com.app.entity.Student;

public class Test {
	
	public static void main(String[] args) {
		
		try(Session ses=HibernateUtil.getSf().openSession()){
			Transaction tx=ses.beginTransaction();
			Student s=new Student();
			s.setId(1002);
			s.setSname("Pratibha");
			Address add=new Address();
			add.setId(102);
			add.setSname("Shivam");
			add.setVillage("Dhanbad");
			add.setCity("Dhanbad");
			add.setHousingNo(1001);
			Classes cls=new Classes();
			cls.setId(103);
			cls.setSname("Mohan");
			cls.setClas_name("BTECH");
			ses.save(s);
			ses.save(add);
			ses.save(cls);
			tx.commit();
			
			// Below line are commented only for create concrete table 
			
			//ses.close();
			
		}
		/*
		 * catch (Exception e) { // TODO: handle exception e.printStackTrace(); }
		 */
	}

}
