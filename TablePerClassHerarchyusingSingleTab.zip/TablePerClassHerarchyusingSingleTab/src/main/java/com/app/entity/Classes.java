package com.app.entity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
/* ............. Using below line for Single Table.................
  @DiscriminatorValue(value = "CLS") */

/* Below line create individual table for every class 

@Table(name="ClassTab")
@PrimaryKeyJoinColumn(name="cid")
*/

/* Below line create Concrete class for independent table for every class*/

@Table(name="Classestable")
public class Classes extends Student  {
@Column(name="className")
	private String clas_name;

	public Classes() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Classes(int id, String sname) {
		super(id, sname);
		// TODO Auto-generated constructor stub
	}

	public Classes(String clas_name) {
		super();
		this.clas_name = clas_name;
	}

	@Override
	public String toString() {
		return "Classes [clas_name=" + clas_name + "]";
	}

	public String getClas_name() {
		return clas_name;
	}

	public void setClas_name(String clas_name) {
		this.clas_name = clas_name;
	}
}
