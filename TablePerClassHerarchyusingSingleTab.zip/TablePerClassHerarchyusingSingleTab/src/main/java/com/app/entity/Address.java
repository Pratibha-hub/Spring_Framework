package com.app.entity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
/* Below line using for single table
 @DiscriminatorValue(value = "ADD") */

/* Below line create individual table for every class 
@Table(name="AdressTab")
@PrimaryKeyJoinColumn(name="Aid")
*/

/* Below line create Concrete class for independent table for every class*/

@Table(name="Addtable")
public class Address extends Student  {
	
	@Column(name="Village")
	private String village;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(String village, int housingNo, String city) {
		super();
		this.village = village;
		this.housingNo = housingNo;
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [village=" + village + ", housingNo=" + housingNo + ", city=" + city + "]";
	}
	public String getVillage() {
		return village;
	}
	public void setVillage(String village) {
		this.village = village;
	}
	public int getHousingNo() {
		return housingNo;
	}
	public void setHousingNo(int housingNo) {
		this.housingNo = housingNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Column(name="HOUSENO")
	private int housingNo;
	@Column(name="CITY")
	private String city;

}
